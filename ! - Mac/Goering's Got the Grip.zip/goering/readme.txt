Goering's Got the Grip, Gunfight To Be Sure and Henry Hitler are three Third Encounter scenarios (respectively 6, 6 and 4 floors) by... wait for it... Richard Peck. You can expect some reasonably pressuring, complex combat scenarios, but also many narrow, long passages that sometimes branch out but eventually seem to converge on the same area. Gunfight seems to be the most linear out of the three. Enemy counts aren't overwhelming (with a few exceptions), yet you should still beware as bosses can be found on pretty much every level. 

===CREDITS===
Richard Peck.